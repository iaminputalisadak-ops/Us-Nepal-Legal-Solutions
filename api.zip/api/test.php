<?php
/**
 * Test DB connection - alias for diagnose.php
 * Visit: /api/test.php or /api/diagnose.php
 */
require __DIR__ . '/diagnose.php';
