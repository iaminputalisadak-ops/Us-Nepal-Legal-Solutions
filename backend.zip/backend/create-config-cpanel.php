<?php
/**
 * One-time setup: creates config.cpanel.php on the server.
 * Visit: https://usnepallegalsolutions.com/backend/create-config-cpanel.php
 * Delete this file after use.
 */
header('Content-Type: text/html; charset=utf-8');

$dir = __DIR__;
$target = $dir . '/config.cpanel.php';
$example = $dir . '/config.cpanel.php.example';
$local = $dir . '/config.local.php';

echo "<h2>Create config.cpanel.php</h2>";

if (file_exists($target)) {
    echo "<p style='color:green;'>✅ config.cpanel.php already exists. Login should work.</p>";
    exit;
}

$content = null;
if (file_exists($local)) {
    $content = file_get_contents($local);
    echo "<p>Copied from config.local.php (your working credentials)</p>";
} elseif (file_exists($example)) {
    $content = file_get_contents($example);
    echo "<p>Copied from config.cpanel.php.example – <strong>edit config.cpanel.php and add your cPanel MySQL credentials</strong></p>";
} else {
    echo "<p style='color:red;'>No config.local.php or config.cpanel.php.example found. Upload backend files first.</p>";
    exit;
}

if ($content && file_put_contents($target, $content)) {
    echo "<p style='color:green;'><strong>✅ config.cpanel.php created!</strong></p>";
    echo "<p><a href='login-test.php'>Test connection</a> | <a href='../admin'>Try login</a></p>";
    echo "<p style='color:orange;'>Delete this file (create-config-cpanel.php) after use for security.</p>";
} else {
    echo "<p style='color:red;'>❌ Could not create file. Check folder permissions (755 for backend/).</p>";
}
