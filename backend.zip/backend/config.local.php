<?php
/**
 * LOCAL database config - override the defaults.
 * Change DB_NAME to YOUR database name (the one that was working).
 * 
 * If your database has a different name (e.g. usneppal, mydb, etc.),
 * change it below.
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'us_nepal_legal_db');  // <-- CHANGE THIS to your database name
define('DB_PORT', 3308);
