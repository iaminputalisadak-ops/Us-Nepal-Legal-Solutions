<?php
/**
 * Diagnostic: tests same config loading as login.php.
 * Visit: https://usnepallegalsolutions.com/backend/login-test.php
 */
header('Content-Type: text/html; charset=utf-8');

echo "<h2>Login Flow Test</h2>";

$configDir = __DIR__;
$cpanelPath = $configDir . '/config.cpanel.php';

echo "<p>config.cpanel.php exists: " . (file_exists($cpanelPath) ? 'YES' : 'NO') . "</p>";

// Same load logic as config.php
if (file_exists($cpanelPath)) {
    require_once $cpanelPath;
} elseif (file_exists($configDir . '/config.local.php')) {
    require_once $configDir . '/config.local.php';
} else {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'us_nepal_legal_db');
    define('DB_PORT', 3308);
}

echo "<p>DB_USER: " . htmlspecialchars(DB_USER) . " | DB_NAME: " . htmlspecialchars(DB_NAME) . " | Port: " . DB_PORT . "</p>";

$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, defined('DB_PORT') ? DB_PORT : 3306);
if ($conn->connect_error) {
    echo "<p style='color:red;'><strong>❌ Connection failed: " . htmlspecialchars($conn->connect_error) . "</strong></p>";
} else {
    echo "<p style='color:green;'><strong>✅ Connection OK - if login still fails, upload the latest config.php</strong></p>";
    $conn->close();
}
