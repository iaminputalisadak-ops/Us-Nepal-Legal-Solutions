<?php
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Backend is working']);
exit;
